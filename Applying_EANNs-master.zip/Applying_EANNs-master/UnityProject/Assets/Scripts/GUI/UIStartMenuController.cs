﻿/// Author: Samuel Arzt
/// Date: March

#region Includes
using UnityEngine;
using UnityEngine.UI;
#endregion

/// <summary>
/// Class for controlling the various ui elements of the simulation
/// </summary>
public class UIStartMenuController : MonoBehaviour
{
    #region Members
    #endregion

    #region Constructors
    #endregion

    #region Methods
    #endregion
}
